// Firebase console > Project settings > Your apps > Web app: copy the config here.
// These values are not secret. Your protection is firestore.rules, not hiding this file.
export const firebaseConfig = {
  apiKey: "PASTE_HERE",
  authDomain: "PASTE_HERE",
  projectId: "PASTE_HERE",
  appId: "PASTE_HERE"
};
