import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore, collection, addDoc, getDocs, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const ALLOWED = ["title","story","genres","sub","themes","tone","demo","age","eps","len","src","status","studio","director","composer","cast","viol","sex","rate","langs","plat","timing","rights","comps"];
const configured = firebaseConfig.projectId && firebaseConfig.projectId !== "PASTE_HERE";
const db = configured ? getFirestore(initializeApp(firebaseConfig)) : null;

function clean(data) {
  const out = {};
  for (const k of ALLOWED) {
    let v = data[k];
    if (v === undefined || v === "" || (Array.isArray(v) && !v.length)) continue;
    if (typeof v === "string") v = v.trim().slice(0, 1000);
    if (Array.isArray(v)) v = v.slice(0, 20).map(x => String(x).slice(0, 120));
    out[k] = v;
  }
  return out;
}

// Public anime catalog (read only for everyone, written only by you in the Firebase console)
export async function loadCatalog() {
  if (!db) throw new Error("Firebase is not configured");
  const snap = await getDocs(collection(db, "catalog"));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}
window.KizunaDB = { loadCatalog };

const btn = document.getElementById("save");
const msg = document.getElementById("saveMsg");
if (btn) btn.onclick = async () => {
  if (!document.getElementById("consent").checked) { msg.textContent = "Tick the box first. Nothing is saved without it."; return; }
  if (!db) { msg.textContent = "Add your Firebase keys in firebase-config.js first."; return; }
  const data = clean(window.getKizunaData());
  if (!data.title) { msg.textContent = "Add a title before saving."; return; }
  btn.disabled = true; msg.textContent = "Saving…";
  try {
    await addDoc(collection(db, "submissions"), { ...data, consent: true, createdAt: serverTimestamp() });
    msg.textContent = "Saved. Thank you.";
  } catch (e) {
    msg.textContent = "Could not save. Check your Firestore rules and keys.";
    console.error(e);
  }
  btn.disabled = false;
};
